JsonAPIClient
=============

This is a code sample on how to consume JSON-based APIs from .NET. The main goal is to keep the implementation as simple, clear and straight forward as possible.

For details and explanations, please read the corresponding blog post at: http://blog.anthonybaker.me/2013/05/how-to-consume-json-rest-api-in-net.html

﻿using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;


namespace JsonApiClientConsole
{
    class Teste
    {
        public static async void GetPost()
        {
            // URL a ser consumida
            var url = "http://localhost:8080/WebApplication2/";

            //Cria o Cliente
            var client = new RestClient(url);

            //Cria a Requisição Web
            var request = new RestRequest("countries.json", Method.GET);

            // Executa a requisição
            IRestResponse response = client.Execute(request);

            // Variável content =  ao conteúdo da resposta da execução
            var content = response.Content;

            // Mostra no console o conteúdo
            Console.WriteLine(response.Content);

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JsonApiClientConsole
{
    class Teste2
    {
        //HttpClient client = new HttpClient();


        //HttpResponseMessage response = await client.GetAsync("http://localhost:8080/WebApplication2/countries.json");
        //if (response.IsSuccessStatusCode)
        //{
        //    var teste = response.Content;
        //}


        //Console.WriteLine(response.Content);
            
    }
}

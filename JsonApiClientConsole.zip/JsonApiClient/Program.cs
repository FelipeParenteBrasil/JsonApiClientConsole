﻿/// Autor:         Felipe Parente
/// Data:          05/01/2017
/// Description:   Consumindo Json Via Console utilizando RestSharp ou JSON.NET
using System;

namespace JsonApiClientConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            // Chama o método GetPost da Classe Teste
            Teste.GetPost();

            //Mantém o console aberto
            Console.ReadLine();
        }
    }
}
